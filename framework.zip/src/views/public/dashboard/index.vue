<template>
  <div class="container">
  </div>
</template>

<script>

export default {
  name: 'dashboard',
  methods: {

  }
}
</script>

<style lang="less" scoped>
.container {
  background: url("~@/assets/images/dashboard.jpg");
  background-size: 100% 100%;
  position: absolute;
  left: -16px;
  top: -16px;
  right: -16px;
  bottom: -16px;
}
</style>
