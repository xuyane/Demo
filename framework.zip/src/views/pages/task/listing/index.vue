<template>
  <div class="container">
    <h2>listing</h2>
  </div>
</template>

<script>
export default {
  name: 'listing',
  data () {
    return {

    }
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>
  .container {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
  }
</style>
