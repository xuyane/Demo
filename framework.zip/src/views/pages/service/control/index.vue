<template>
  <div class="container">
    <h2>control</h2>
  </div>
</template>

<script>
export default {
  name: 'control',
  data () {
    return {

    }
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>
  .container {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
  }
</style>
