import lazyLoad from './modules/lazyLoad'

const directives = {
  lazyLoad
}

export default directives
